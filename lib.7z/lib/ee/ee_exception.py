#!/usr/bin/env python
"""A simple exception for the EE library."""




class EEException(Exception):
  """A simple exception for the EE library."""
  pass
